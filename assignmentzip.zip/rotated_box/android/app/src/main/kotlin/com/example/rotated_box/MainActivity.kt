package com.example.rotated_box

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
